@extends('admin_layout')
@section('admin_content')
<h3><center>Chào mừng bạn đến với đồ án hướng dẫn website của anh Hiếu nhé</center></h3>
@endsection